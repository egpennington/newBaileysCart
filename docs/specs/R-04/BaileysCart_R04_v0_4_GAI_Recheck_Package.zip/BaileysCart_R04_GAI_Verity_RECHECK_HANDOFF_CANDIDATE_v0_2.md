# GAI — R-04 Independent Recheck Handoff v0.2
**Project:** Bailey's Cart / newBaileysCart  
**Author:** CipherMuse  
**Status:** CANDIDATE FOR GAI RECHECK — NOT RATIFIED  
**Authority:** Project Lead approves architecture, Gate C, merges and release.  
**Evidence:** Source files mounted for review; no Git checkout/SHA verified. No implementation, provisioning, tests, or deployment authorized. All Verity ProofPoints `NOT_RUN`.  
**Workflow:** Pennington Labs Engineering Workflow v2.4.  
**Source hierarchy:** `API_SPEC_v0.2.md`; `API_SPEC_v0.3_REV1_RATIFIED_COPY.md` (filename/header status discrepancy); `API_SPEC_v0.3_RATIFIED_ADDENDUM_P4D10_P4D11_v0.1.md`; `ARCHITECTURE_v1.1.md`; `newBaileysCart_PRD_v1.0_GAI_Review.md`; R-04 candidates; `GAI_R04_Contract_Reconciliation_Review_Report.md`; explicit PL Decisions 33–45. Existing source conflicts are flagged, not erased.  

## Review packet
1. `API_SPEC_v0.4_CANONICAL_CANDIDATE.md`
2. `PRD_v1.0_R04_PROPOSED_AMENDMENT.md`
3. `ARCHITECTURE_v1.1_R04_PROPOSED_AMENDMENT.md`
4. `BaileysCart_R04_Authorization_Error_Matrix_CANDIDATE_v0_3.md`
5. This handoff; compare against prior R-04 four files and `GAI_R04_Contract_Reconciliation_Review_Report.md`, API v0.2, v0.3 Rev1, P4-D10/D11 addendum, PRD v1.0 and Architecture v1.1. Review workflow v2.4. Verify canonical repository paths/SHA; current files are sandbox candidates only.

## Explicit delta traceability
- D33 revised by **D42**: one owned family per UID, multiple invited memberships; D34 trial; D35 owner payer; D36 expiration; D37 no transfer; D38–41 closure and recovery; D43 epoch; D44 pending-cancel restore rejection; D45 paid family reservation.
- Preserve existing item, Unicode, clear, offline, revocation, invite race, account deletion and P4-D10/D11 semantics except explicit later decisions.
- Earlier source contradictions must be reported; candidate amendments do not silently amend approved Git files.

## Prior GAI findings — proposed disposition, NOT VERIFIED
| Finding | Candidate remediation | Evidence still needed |
|---|---|---|
| BLK-01 | D42 removes multiple owned subscriptions per UID | Real Play purchaser/account binding, product constraints and verified API behavior |
| BLK-02 | D45 unentitled family reservation | Reservation TTL/expiry, delayed purchase, provider correlation and retries |
| BLK-03 | D44 rejects restore while cancellation pending | Cancellation provider finality, outage and escalation scenarios |
| BLK-04 | D43 `familyEpoch` on all family mutations | Epoch atomicity, immutable opId binding, migration, stale replay tests |
| BLK-05 | Controlled PRD/Architecture amendment candidates | PL ratification and verified repo SHA |
| MAJ-01 | Account deletion saga restored | Retention conflict, provider failure, partial progress, account deletion obligations |
| MAJ-02 | Matrix includes leave, closing invites, closing billing | Exact error mapping and privacy-safe precedence |
| MAJ-03 | Family-scoped local partition/purge | Physical design, key handling, crash safety, offline device limitations |
| MAJ-04 | Canonical WP-03 IDs below | Registry collision check and alias mapping |
| MIN-01 | `account.getSession` callable candidate | Auth/Firestore rule review, response contract and source selection approval |
| MIN-02 | Clear All limit remains OPEN | Firestore transactional feasibility; 300-item cap is not PL-approved |

## Verity canonical ProofPoints — proposed mapping (all NOT_RUN)
| ID | Suite | Depth 1 / 2 / 3 / 4 challenge |
|---|---|---|
| PL-PP-WP03-14 | PS-ACCESS-ISOLATION | Contract owner/member distinction; emulator cross-family deny; device switching; adversarial membership leakage |
| PL-PP-WP03-15 | PS-BILLING-LIFECYCLE | Atomic trial ledger; concurrent creates; offline/reinstall; GAI duplicate trial attack |
| PL-PP-WP03-16 | PS-BILLING-LIFECYCLE | Owner-only purchase binding; emulator token reuse; device purchase recovery; forged/non-owner provider result |
| PL-PP-WP03-17 | PS-ACCESS-ISOLATION | Closure state transitions; backend read deny; offline cache restriction; closure vs queued write race |
| PL-PP-WP03-18 | PS-BILLING-LIFECYCLE | Cancellation durable saga; provider outage/retry; device pending UX; GAI duplicate/cancel ambiguity |
| PL-PP-WP03-19 | PS-ACCESS-ISOLATION | Pending restore error, owner-only restore, epoch increment; emulator race; old device replay; adversarial idempotency |
| PL-PP-WP03-20 | PS-RETENTION | UTC 30-day strict boundary; fake clock; device recovery UX; GAI deadline race and retention leakage |
| PL-PP-WP03-21 | PS-CORE-LIST | Canonical key fixtures; backend collision; Kotlin parity; GAI multilingual/combining marks |
| PL-PP-WP03-22 | PS-OFFLINE-SYNC | Immutable epoch queue; backend stale rejection; device upgrade; GAI old-op mutation attempts |
| PL-PP-WP03-23 | PS-ACCOUNT-LIFECYCLE | Owner account deletion saga; joined-family cleanup; device privacy; GAI provider partial failure |
| PL-PP-WP03-24 | PS-BILLING-LIFECYCLE | Unentitled reservation; pending/delayed purchases; Play sandbox device; GAI orphaned purchase/expiry |

**Four-deep standard:** D1 schema/unit, D2 Firebase emulator/integration, D3 Android device E2E, D4 GAI adversarial independent verification. No proof execution evidenced. GAI should confirm `PL-PP-WP03-01..13` and `14..24` uniqueness; aliases `PP-R04-*` are historical references only.

## Required GAI output
- Verdict `PASS / CONDITIONAL / FAIL` for **specification readiness**, distinct from implementation test results.
- Severity-ranked findings with exact file/section references; blockers vs nonblocking decisions.
- Verify policy traceability D33→D42 and D34–45, account deletion and source precedence.
- Explicit evaluation of Play billing uncertainty; do not assume same product can be purchased twice, nor that distinct app emails guarantee different Play purchasers.
- Review security of stale-epoch/idempotency ordering and access revocation.
- Review 24-hour TTL as unapproved candidate, deletion SLAs, billing cancellation, account deletion and retention conflict.
- Report missing normative wire schemas, Unicode vectors, clear scaling and local purge specifics.
- Return proposed remediation, ProofPoint updates, and evidence needed for Gate C.

## Authority / gate
GAI performs independent specification review only. CODI implementation prohibited until scoped PL Gate C authorization. FORGE execution/build/deploy not authorized. All ProofPoints `NOT_RUN`. PL alone ratifies baselines, authorizes Gate C, merges and releases.
